
function myFunction() {
    document.getElementById("myText").value = "Johnny Bravo";
    var ayam = document.getElementById("myText").value;
    document.getElementById("tes").innerHTML = ayam;
    return false;
}
