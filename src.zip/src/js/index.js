var ayam = document.getElementById('mytext').value;
var password = document.getElementsByName("last").value;



function pindahlaman(){

  alert(password);
  return false;
}
